Kurophase is a easiest to use properly licensed to.
- To use PowerPoints.
- To use everywhere, Also want. 
(e.g. In Game Custom.)

Licenses is free to used, does required anybody to 
use! But. It's fine to be used as yours font installed in.
I glad supported thing!! This what I have to Github
publishing.

Updates ///
 + Updates is no longer don't ask any problems.

Thank you.